function isEmpty(obj){
  if(obj ==null||obj=='null'||obj==''||obj==undefined||obj==false||obj.length==0){
    return true;
  }else{
    return false;
  }
}