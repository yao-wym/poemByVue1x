var HOST = "http://123.56.136.248";
var HOST_API = "http://123.56.136.248/app/index.php?";
var ARTICLE_LIST_API = HOST_API+"act=cms_article&op=article_list&class_id=1";
var LOGIN_API = HOST_API+'act=login';
var HOTEL_LIST_API = HOST_API+'act=shop&op=hotel_list&key=store_credits';
var SHOP_LIST_API = HOST_API+'act=shop&sc_id=3';