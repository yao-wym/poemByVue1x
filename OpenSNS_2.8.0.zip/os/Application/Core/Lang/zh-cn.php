<?php
return array(
    '_FOLLOWERS_'=>'关注',
    '_SUCCESS_'=>'成功',
    '_FAIL_'=>'失败',
    '_PLEASE_'=>'请',
    '_LOG_IN_'=>'登录',
    '_CANCEL_'=>'取消',

);