<template>
    <ul style="font-size: 0.3rem">
      <slot></slot>
    </ul>
</template>

<script type="text/javascript">
module.exports = {
  replace: true,
  components: {
  },
  data: function(){
  }
}
</script>

<style lang="stylus">
</style>