<template v-transition>
    	<app-header title='游记'></app-header>
      <flex-scroll-view transition="bounce">
          <!-- <app-pane side="left" msg="1123" name="{{leftName}}"></app-pane> -->
      </flex-scroll-view>
</template>

<script>

	module.exports = {
  replace: true,
  components: {
    'app-header': require('../components/CommonHeader.vue'),
    'app-pane': require('../components/IndexHomePane.vue'),
    'index-tab': require('../components/IndexTab.vue'),
    'flex-scroll-view': require('../components/FlexScrollView.vue'),
  }
}
</script>

<style lang="stylus">
  @import "../main.styl"
</style>